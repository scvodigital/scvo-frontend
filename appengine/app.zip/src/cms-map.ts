export const CmsMap: { [name: string]: string } = {
    "goodmoves": "cms.goodmoves.com",
    "goodhq": "merida.goodhq.org",
    "scvo": "cms.scvo.org"
};
