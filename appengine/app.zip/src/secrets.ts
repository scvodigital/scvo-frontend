export const Secrets = {
    elasticsauceToken: "c2FsZXNmb3JjZTpKVHVTaXlUYlRCXl4qM0ghaCY3OGhsVldlb04hZEwydw==",
    configs: {
        default: {
            credential: {
                type: "service_account",
                project_id: "scvo-net",
                private_key_id: "e75bf1e9052b5bb973100bddfcbcdf7c3e579987",
                private_key: "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQC6l0WttNoiaG7A\nYVoXkYbcNk6CznF9eVgA6RejKEYqUlkGMpmknaSBNtpor+r7zXGIs55B9huoBDe5\nCUwkqBSZ0FsEDQYrGU1+H0wniJ7JnFBy5JqiBLMz2lKJIc/Apu2c6jhm8exu4YQ4\n/Qmo+ApDtkO9OYgEmvAQCuMHtUcnIwB0RW2uziY00wvmp71uIEYNwPlyBBC4EKXl\nSbwkLWtFJAEygQ7FiBk9C5nuY7scpOEcJgauIkAWUENNHZipaQomFA5qHeGnY6kf\nKcYWb7t7QJ+IRPnad3zXwc+XPnNf+lVm/Xi6FG7ls8L5krJunfLTjdbtSKOUkPg8\nO1VpRS3PAgMBAAECggEAC1IaG+/X2/QjrKJABCOfaPdfYxEGJLbxpm9ZZ25FCdRy\nxiP9EkP4QMZttX1NKyCQe1r+fW9QNT85Z7IYWxFIbh6e3MJp0VKY5T1nTcpza9ne\niRjZdTUrFDipI27zqKohOKNaJkMWUNsKB3CMepAs39NDMidb7X+Z3YBzl/FYCgXN\nq+gDQ6A+7TbhMtFKK/PYoPCH9SAWp98TTMvX5bTm3qJlcaUBWCliHKGcrF9F5flS\nzhOSkfPecy4eMdn+8718GTgmT4fnt0ctzsoP6OOEtprk5jx5gtO6Unw8nId+IzD/\nxOkRBziAoaw6BQSsj/zRGhrQ71h9PheOMexg/nT7ZQKBgQDsCp27I5MYydjby5El\nxWrgzJsihckkLZ8fr7OMP0rRE2kR0JTfqLt7rim0V6l1XnfAV+fhpVHM1YjfNH5k\nM62s72TM5ZW391WLrmCii8XhzIfuFveSodj4M+esgT5IjPMDjxEdJtt0kqK4NBxt\nkOPip4Hgm8tVePH4qZaYQ0yWdQKBgQDKXj4q5g94lfAOzXYxQ/d3Kq1XAclIsZGZ\nT8uIwfFcBpObHdTxSiRwZbDJCTezTU7dc5jqQFNNAtVm/tCp4QZ+2FkFugLNBj9f\nHiK83QXhCFg7ydBbFX8tU+mS0ayvJsN0GdfvFKhf0BDYgmUQfCAmdB1jlFLhXViS\nlnu7eJzSswKBgQCj6UNbHvsY7aIgD569wffUH4FjWdAxxVSIpnRiYdlMktQVwOiA\n4CVBX9IqH+3XSUCTWvf1Y94IBgjEJynV32UtgBhZiNyNIb5P/0mv1qwVfvitx1ko\nhCetRC4PRri/nNFsmT7jJYajzugcTmOnWkRFstin5sgulIxDh1DCb4mRuQKBgHtU\nHAcA1gTjO72JsbIsfa/+Lk2MJSNMNDN+0ceyimlPCL3L3G6AhNyK3MZn+64mOx3y\nyQpZ0Wppg6yVNo2ROegr6XT3+6T/XbeWIg1/lYmjEEK/p18bJrp1HTAA4ICN2yfy\naAqoSES8BMguD3GQc/d7ZD2/sxLtVIFhfF6wDsLJAoGAWFjpiJyo2LYzgj2+HDw2\nCr3XIJCekh0BsG5rl6qJSDzCJIIOzXLVq6AIEE2vgmGQhQoTHuRPBVhGcKG8Ot8h\naN5OSD3/T+FrRGRRYJuQM/dMmL+b2jtAK+Ma8bIBXbDXWJByz+qxn4oy8GmBKuF7\nbN/e5N+u8rIRzjv1ONu6e3o=\n-----END PRIVATE KEY-----\n",
                client_email: "scvo-net@appspot.gserviceaccount.com",
                client_id: "117500144193081474249",
                auth_uri: "https://accounts.google.com/o/oauth2/auth",
                token_uri: "https://accounts.google.com/o/oauth2/token",
                auth_provider_x509_cert_url: "https://www.googleapis.com/oauth2/v1/certs",
                client_x509_cert_url: "https://www.googleapis.com/robot/v1/metadata/x509/scvo-net%40appspot.gserviceaccount.com"
            },
            databaseURL: "https://scvo-net.firebaseio.com"
        },
        fundingscotland: {
            credential: {
                type: "service_account",
                project_id: "scvo-auth-fs",
                private_key_id: "024eddb3c57a1afac942f5a3379a9e37645f18d8",
                private_key: "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQDzW+a0Mv4ngXui\nKn51pwAmI+nDKpFhMtmFffvxMat3Q5i+vDt5MhfKZNTVULga6TvwIShTSetYaQOb\nLcANtYzTlL9/3xZs/da8rHsS0c6EeY/T3tOMmpHHskDwtJMnSVQLKVZqwKgxecod\nU00yzYdchKNBlhTw09OkkMs+gYki887Z0d8rjPMt7ApRYHEGpCqH+LdDfr2DkJzV\nvnKSrhODKQufMYffpPZkh/Zm/fJbOhLrcGSgeCDXbA0lKw1/KhLgjLQe7A6AlfXP\nZHu4ShtXdZmPauTK2fXMx9weZcyRVhMDKE3AFmRqpKBlE/RHEuRZy74XHqBwaMZE\nQu/6y973AgMBAAECggEAIREmuuuG30VX0EQn5MKpYYVVuSAqmuN27Q2eUzqlitIT\nii83gZNN6kFjLg0GxxlT/J/0w8RyhxPV2psP0o0Nsp4umyhr+qlPKVniaz846YU/\nBtHrOtqx3kmZS1ut9xOeqNmYFW9SK07aKLvt7G5C605WhI3pEIQn6N+Hzll5kdb9\nN/V8Jp28nzbgmirRDTdceIcCtLiKizi2mgy886huzbsPO3m7k5b6UOZsJfXqftV2\nEJNgwSWf5cj9bz/O5rwnNawlor1ITsNdE9JMzZ2llT8qTJj8CouOWCzR5y0CGemA\nwH4940Nwp/Fgp8GtMrmi8/I4Ozu393CDA2Ga6S4RcQKBgQD+BXJK41pfHjuEU2x8\nE5o/+HP0wp6u8nSOmSXR4Ci8td8hoQp94whDGjRYRDSKnl20F4QGcHkWoX2P9EuB\nuqXHe8++g2/4F3MVv62x0K6Zu/yCGM1Hy2i8AOaKqRwrN5YVC1JvUtZ09vwacBms\nlSz9+rj6xX16J8Xk7lnfAtJX/wKBgQD1QTFSGflkV1f8M7ptDp/14/dQPP6NAcPk\nEgLD0N4Za6LVE+MMeoMPWDgpfqJo88yelu+xdH3Ydwx+2fYb1iM+Qr9znNaVpcZl\n2UiNIlOSxdrKQNlVQbBjWEe3SIeaT0SztmBsOcC6bf52V82qJRh6CFX/ypohGsUF\nCyXqzDE5CQKBgF3uUacTjxVhLozt9E2lSgKhsu8tEFSM30DjrLKA+09cyVe8Hw8R\n5ro5dGW3Qt6HVQsFLxLagEw4ByA2K72a8TZkuBswqzTIJwxBxs7b5dR/SQ4qca48\nr0vl4Vog0oPAmETL3P3BWgACXJLCJRxGRU7daY2BfbawAmN3J9BpULKtAoGAY++x\nukPNRN72glVNxPytn9PJxg9kpm6utPPF3qbwqakbi/nzjfUqDImlMPtiEKQvn/vf\nJg9S7G7uT45fY85pRAiM3P5uzkHjy0Kz9pajOW6YDcxJAx2mU4T4jC3o268rTpOl\nTNRnvU/u3ag/rPI6vBdDe9zB23V+DOUTCU81S4kCgYEA9uj75mSxi7Ens93P7ONp\ndZiey+aKGA0JYCxXeG5ShbNhSjNVevsURSDur/CNUUWTCyfp0qG5InbbbEMU4PNg\nXRe1CTO4dOevNlvkBl8Ypzf41jsKklkLzblhFCamkCzEgPMoO6eF88S0dBnSZx2h\nZfwBiDCYcFSJRMMvI0z6lxA=\n-----END PRIVATE KEY-----\n",
                client_email: "firebase-adminsdk-1gci5@scvo-auth-fs.iam.gserviceaccount.com",
                client_id: "111343601425212985286",
                auth_uri: "https://accounts.google.com/o/oauth2/auth",
                token_uri: "https://accounts.google.com/o/oauth2/token",
                auth_provider_x509_cert_url: "https://www.googleapis.com/oauth2/v1/certs",
                client_x509_cert_url: "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-1gci5%40scvo-auth-fs.iam.gserviceaccount.com"
            },
            databaseURL: "https://scvo-auth-fs.firebaseio.com"
        },
        goodmoves: {
            credential: {
                type: "service_account",
                project_id: "goodmoves-frontend",
                private_key_id: "833069c6ba3f6c5471f05ccfc4257a8b9f62f7e6",
                private_key: "-----BEGIN PRIVATE KEY-----\nMIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQCswY3gPbRDKw5+\n7S29D2nTlVarYlu4WdEWmiRpP4LKp2ibWW7Ncb2KSL/DMnbAKKRouyqDmSzKPKkr\naqXtP/PDk7in8p8alLGh4joY1HPI7W0QJJURgs5KWLMYgOzGhdVOX5ai+BfXUelZ\niAw79+dU/z0fYe1B5QYVZ9sa6MC/O1vbvOyUSV4fyzTUDoyjWA7shTOtL7tm5JR2\nZPSjH0GBbtK9LTWvsfZBRe6vO/vucEG/Dv3LOTo08jp+0hLobyQby/hcitPx1mLm\n9U4fweABGecla6wA7f6AOaoaglJpSJiLLAZ8VHgOUlk+dZgkkTh8UW1deuLDFb4F\nzqaRgxBjAgMBAAECggEATYwi7i50nRQWUTaRagUhuYcXXR5tUq8Ksw0lXBNU2DhW\ntilqmhE9BnaKkgo0kSSNTK/7sRAQsYWSYLliW0HyX/APG2DHN8zYgfUFpEC16tNd\nOjpZqf8gL/JqDo1M+/52llRFT8lzFkYgK/7skvzAnIBohQ5VzNcMKI6ypX0mjJBQ\nv8Rkw1ZS84jE+EhRRXgYaKHyA5H0BZBP1BCrGUb2C7zk6gb3D/3sbBs5G+b+87z3\niHzhI8cScZ+ANPROKYdK5f44FGc1IXslKjwdIw68CajUyIKRuI/0SPrlOfwq2FYz\nN70ulXpRxIDaW0Bgw3c0cmXRJN4CXCVmEE3+NEYs7QKBgQDksZa4s0fW0aNz906a\n7tBoC73CWKOOl7yQUBdE446qe7X/GbB4YS93XQ4BEPMJs0wmIuMopili2EaszGD5\nJOsqWirLaTjQtzegRbL5FGz9/UwdBDyDdZDkSFGKUe82NN5oehPxDMs+Uh0a/GUo\n9dVsOcJLCNUfvaOoKqcTCfRa9wKBgQDBYiL+5it7lb2MuCw5B1kZ/rKl4a1PvSl5\niDWzzcz/F59eH4AomTQb1hXMC3xLLk+GLxVoCr/gZ/GuG6l5v5HO3tHHryRZOZUM\nLQzSAOu1pyecuDaTJ+grp0ceKV9SWCCf92b7Zdw5H4yOVl5IRvkqSwGoENuHjyGC\n/HYGWaWO9QKBgDeEvVhdfaUzA4FVmmmWbFW18/1IU3x8bbSDHQMGU04j9kzVybeP\nsFxD5PBxUu8Z7fScJ5VosUdjxdSRUUFqqwR/G0CCbN6OfByWjxpU0Rjf8yhgLOil\nE+W3gMQZm/8G2q92Y3zzZCve913jxBMriwJZC0f3/vVTrnVW1XSTyBSFAoGAZZ1w\nsCo4LQ9o87mPG0ReMIeiTgIA9MZ8Na06MsnwbxZ1mprI2Axw0jOzbm2WmVazWNoC\n0JHdc0iLOSa17hCYyHBTIS9J1UypoiVF+E+di+1Spkox+y9cExwqBZJN0VIXipcQ\n2QcUKjwGuoBtuGL66JtTOoHpKRkvzcllJz8R/MUCgYA79qfkqvD8+pCNv0KFWc3i\nmO16SrLo8kjrikJ5aBMpD2sNMJcKlwaQWp3ut7DqbHP22tihUCl0HEO0jjMdx33t\nIrXVXwW8HGg7WjbHMc1tZCYtEiWk6pRTUnrniLFPZQZEz3OFvSiderDpDlsJz05z\nA/eoh+NDxzObr4sUh2owYw==\n-----END PRIVATE KEY-----\n",
                client_email: "firebase-adminsdk-h518g@goodmoves-frontend.iam.gserviceaccount.com",
                client_id: "115298376187981494319",
                auth_uri: "https://accounts.google.com/o/oauth2/auth",
                token_uri: "https://accounts.google.com/o/oauth2/token",
                auth_provider_x509_cert_url: "https://www.googleapis.com/oauth2/v1/certs",
                client_x509_cert_url: "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-h518g%40goodmoves-frontend.iam.gserviceaccount.com"
            },
            databaseURL: "https://goodmoves-frontend.firebaseio.com"
        }
    }
}
